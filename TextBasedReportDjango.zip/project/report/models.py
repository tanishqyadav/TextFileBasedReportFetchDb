from django.db import models

# Create your models here.

# class sample(models.Model):
#     name = models.CharField(max_length=20, blank=False, null=False)
#     phonenumb = models.IntegerField(blank=False, null=False)
    

class MarksheetVerification(models.Model):
    id = models.BigIntegerField(primary_key=True)
    inst_code = models.CharField(max_length=255, db_collation='utf8_general_ci')
    inst_name = models.CharField(max_length=255, db_collation='utf8_general_ci')
    prog_code = models.CharField(max_length=255, db_collation='utf8_general_ci')
    prog_name = models.CharField(max_length=255, db_collation='utf8_general_ci')
    session = models.CharField(max_length=2)
    registration_number = models.BigIntegerField()
    roll_number = models.CharField(max_length=255, db_collation='utf8_general_ci')
    aadhar_number = models.CharField(max_length=255, db_collation='utf8_general_ci', blank=True, null=True)
    first_name = models.CharField(max_length=255, db_collation='utf8_general_ci')
    middle_name = models.CharField(max_length=255, db_collation='utf8_general_ci', blank=True, null=True)
    last_name = models.CharField(max_length=255, db_collation='utf8_general_ci', blank=True, null=True)
    sex = models.CharField(max_length=255, db_collation='utf8_general_ci')
    dob = models.CharField(max_length=10)
    category = models.CharField(max_length=255, db_collation='utf8_general_ci')
    mobile_number = models.BigIntegerField(blank=True, null=True)
    email = models.CharField(max_length=255, db_collation='utf8_general_ci', blank=True, null=True)
    father_name = models.CharField(max_length=255, db_collation='utf8_general_ci', blank=True, null=True)
    mother_name = models.CharField(max_length=255, db_collation='utf8_general_ci', blank=True, null=True)
    exam_held_year = models.CharField(max_length=4)
    exam_held_month = models.CharField(max_length=2)
    result = models.CharField(max_length=255, db_collation='utf8_general_ci', blank=True, null=True)
    printing_date = models.CharField(max_length=10, blank=True, null=True)
    marksheet_no = models.BigIntegerField()
    is_duplicate = models.IntegerField()
    is_duplicate_issued = models.IntegerField()
    obtained_marks = models.IntegerField()
    max_marks_upto_6th = models.BigIntegerField()
    number_40_per_marks = models.IntegerField(db_column='40_per_marks')  # Field renamed because it wasn't a valid Python identifier.
    obtained_marks_upto_6th = models.BigIntegerField()
    cgpa = models.FloatField(blank=True, null=True)
    sgpa = models.FloatField()
    semester = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'marksheet_verification'