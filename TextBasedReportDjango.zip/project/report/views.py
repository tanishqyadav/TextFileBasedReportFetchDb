import ctypes
from django.shortcuts import render, redirect
from django.http import HttpResponse, FileResponse
from tabulate import tabulate
from .models import *
from .helperReport import *

# Create your views here.



def report(request):
	response = HttpResponse(content_type='text/plain')
	response['Content-Disposition'] = 'attachment;filename = report.txt'


	name = 's,b,t,e'

	response.writelines(['  Name:{}\n'.format(name)])
	response.writelines(['*'*len(name)*2])
	response.writelines(['\n'])

	response.writelines(['  REPORT: \n'])

	response.writelines(['here\n'])

	fields_names = fieldsNameFullDb(MarksheetVerification)
	
	response.write((tabulate(customQuerysetFullDbReportTable(ModelObj=MarksheetVerification.objects.filter(id=38), MyModel=MarksheetVerification), headers=fields_names, tablefmt='psql',)))

	return response



def dashboard(request):
	return render(request,'report.html')



